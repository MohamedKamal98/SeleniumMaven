package data;

public class ReadFromDatabase {
}
