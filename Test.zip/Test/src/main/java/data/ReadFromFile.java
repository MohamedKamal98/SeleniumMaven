package data;

public class ReadFromFile {
}
